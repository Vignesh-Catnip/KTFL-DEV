"""Application settings (environment variables / .env). Passwords never live in code."""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_env: str = "development"

    # ---- application database ----
    database_url: str = "sqlite:///./clearmatch.db"

    # ---- SAP data lake (SQL Server, read only) ----
    sap_enabled: bool = True
    sap_server: str = ""
    sap_database: str = "BRONZE_DB"
    sap_user: str = ""
    sap_password: str = ""
    sap_driver: str = "ODBC Driver 17 for SQL Server"
    sap_client: str = "150"                  # MANDT filter ("" = no filter)
    sap_db_url: str = ""                     # full SQLAlchemy URL override (tests / other drivers)
    grn_movement_types: str = "101,105"
    # Where SAP keeps the HSN / SAC / NCM code, as TABLE.COLUMN list, e.g. "MSEG.J_1IG_HSN_SAC,EKPO.STEUC,MARC.STEUC".
    # Empty = auto-detect: every column of MSEG / EKPO / MARC whose name contains HSN, NBM (NCM), STEUC or STAWN.
    sap_hsn_columns: str = ""

    # ---- Ollama ----
    ollama_url: str = "http://localhost:11434"
    model_vlm: str = "qwen3-vl:32b"
    num_ctx: int = 24576                     # 2 pages x ~4-5k image tokens (image_long_side 2400) + prompt + answer; lower image_long_side if the GPU is small
    num_predict: int = 6144
    vlm_timeout: int = 900
    main_pages: int = 2
    grn_pages: int = 3
    image_zoom: float = 1.4
    image_autorotate: bool = True            # landscape photo of a portrait invoice -> turn it upright
    image_max_side: int = 1800               # photos are shrunk to this many pixels (longest side) before reading
    grn_zoom: float = 2.0
    image_long_side: int = 2400              # PDF pages are rendered with this many pixels on the longest side
    totals_width_px: int = 2600              # width of the totals-box crop used for the second read of the amounts
    tesseract_cmd: str = ""                  # full path to tesseract.exe if it is not on PATH (Windows: C:\\Program Files\\Tesseract-OCR\\tesseract.exe)
    ocr_evidence: bool = True                # tesseract text used to check GSTIN / PO read by the model (needs the tesseract binary)
    totals_pass: bool = True                 # second focused read of subtotal/tax/total when the first read does not add up

    # ---- matching thresholds ----
    amount_tolerance: float = 0.02           # 2 % invoice taxable value vs GRN value
    round_tolerance: float = 1.0             # INR slack for rounding
    qty_tolerance: float = 0.001
    ktfl_gstin_prefixes: str = "27AABCK0618A"

    # ---- files ----
    upload_dir: str = "./data/uploads"
    pdf_search_dirs: str = ""
    watch_folder: str = ""                   # 1. INPUT folder
    processing_folder: str = ""              # 2. (empty = "processing" next to the input folder)
    output_folder: str = ""                  # 3. output\\matched | reconcile | blocked
    finish_folder: str = ""                  # 4. finish\\posted | parked | duplicate
    error_folder: str = ""                   # PDFs that could not be read
    exception_folder: str = ""               # PDFs that are NOT material invoices (service PO 81/82/83, SAC 99xx) - moved here, not extracted
    gst_rate_xlsx: str = "./data/GST_RATE.xlsx"
    max_upload_mb: int = 25
    allow_upload: bool = False               # intake is the watched folder; upload from the browser is off
    watch_settle_seconds: int = 5            # a PDF must be unchanged this long before it is picked up
    min_completeness: float = 0.70           # >= this share of mandatory fields read -> RECONCILE, below -> BLOCKED

    # ---- auth ----
    jwt_secret: str = "change-me"
    jwt_algorithm: str = "HS256"
    jwt_expire_minutes: int = 720
    admin_username: str = "admin"
    admin_password: str = ""

    # ---- behaviour ----
    worker_enabled: bool = True
    # ---- MIRO robot (Robot Framework + SAP GUI) started from the dashboard ----
    robot_enabled: bool = False
    robot_dir: str = ""                      # folder that contains tasks/miro_posting.robot  (its own .env is used)
    robot_python: str = ""                   # python that has robotframework installed ("" = this python)
    robot_task: str = "tasks/miro_posting.robot"
    robot_mode: str = ""                     # CHECK / PARK / POST - "" = whatever the robot's own .env says
    robot_auto_run: bool = True              # start the robot by itself when matched invoices are waiting
    robot_auto_delay_seconds: int = 60       # wait for more invoices before starting (one SAP session at a time)
    robot_timeout_minutes: int = 120
    robot_log_dir: str = "./data/robot_runs"
    log_dir: str = "./data/logs"             # backend.log (extraction, folder pickup, robot start) - one file per day, 30 days kept
    watcher_poll_seconds: int = 20
    cors_origins: str = "http://localhost:5173"
    plant_names: str = "{}"

    # ---- helpers ----
    @property
    def grn_types(self) -> tuple[str, ...]:
        return tuple(x.strip() for x in self.grn_movement_types.split(",") if x.strip())

    @property
    def gstin_prefixes(self) -> tuple[str, ...]:
        return tuple(x.strip().upper() for x in self.ktfl_gstin_prefixes.split(",") if x.strip())

    @property
    def search_dirs(self) -> list[Path]:
        dirs = [Path(self.upload_dir)]
        dirs += [Path(x.strip()) for x in self.pdf_search_dirs.split(",") if x.strip()]
        return dirs

    @property
    def cors_list(self) -> list[str]:
        return [x.strip() for x in self.cors_origins.split(",") if x.strip()]

    @property
    def plant_name_map(self) -> dict[str, str]:
        try:
            data = json.loads(self.plant_names or "{}")
            return {str(k): str(v) for k, v in data.items()}
        except Exception:
            return {}


@lru_cache
def get_settings() -> Settings:
    return Settings()


def reset_settings_cache() -> None:
    get_settings.cache_clear()
