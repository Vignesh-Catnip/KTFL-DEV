"""
Decides which dashboard queue an invoice belongs to.

    BLOCKED    mandatory data is missing from the invoice itself
               (no invoice no / date / vendor / PO / GRN / plant / GST tax code)
    RECONCILE  every field is present but something does not agree with SAP, or SAP does not have the
               PO / GRN the invoice names (line quantity / amount, GRN value, tax code, HSN, arithmetic,
               PO/GRN not found in SAP, invoice linked to several POs ...) - a person checks and pushes it
    MATCHED    everything present and everything agrees with SAP  -> robot posts it automatically

HSN rule: the invoice's own HSN is the only HSN ever stored. SAP's HSN is compared with it:
    not printed on the invoice -> RECONCILE   not in SAP -> RECONCILE   different -> RECONCILE
"""
from __future__ import annotations

import re

from ..config import get_settings
from ..models import (QUEUE_BLOCKED, QUEUE_MATCHED, QUEUE_RECONCILE, STATUS_MANUAL, STATUS_MATCHED,
                      STATUS_REVIEW)
from .textutil import (GSTIN_RE, GST_STANDARD_RATES, grn_is_valid, gstin_ok, is_service_po, is_valid_po, norm_hsn)

BLOCK, RECON, INFO, WAIVED = "BLOCK", "RECON", "INFO", "WAIVED"

# ---- NEW: settings for the extra invoice-internal checks -------------------------------------------------------
BUYER_STATE_CODE = "27"       # KTFL is in Maharashtra: seller state 27 -> CGST+SGST, any other state -> IGST
QTY_RATE_SEVERITY = RECON     # set to INFO if discounted lines cause too many false alarms

MANDATORY_FIELDS = ("invoice_number", "invoice_date", "vendor", "po_number", "grn_number", "subtotal", "total",
                    "gst_tax_code", "gstin", "hsn_sac")      # 10 fields that must come from the invoice itself
FIELD_MISSING_CODES = {"MISSING_INVOICE_NUMBER", "MISSING_INVOICE_DATE", "MISSING_VENDOR", "MISSING_PO", "MISSING_GRN",
                       "INVALID_GRN", "MISSING_TAXABLE_VALUE", "MISSING_TOTAL", "MISSING_GST_TAX_CODE", "MISSING_GSTIN"}

# Issues a person with "Accept variance" may waive. Everything else (arithmetic, tax, totals, missing / unread values,
# vendor, currency, pages, lines) must be fixed in the data, then re-checked.
WAIVABLE_CODES = {"AMOUNT_MISMATCH", "QTY_MISMATCH", "GRN_VALUE_MISMATCH", "LINE_NOT_IN_GR", "PRICE_MISMATCH",
                  "LINE_POSSIBLE_DUPLICATE"}

# category -> label used by the Error-flow screen
CATEGORY_LABEL = {
    "MISSING": "Data missing", "QUANTITY": "Quantity mismatch", "PRICE": "Price / amount variance",
    "TAX": "Tax code", "HSN": "HSN / SAC", "SAP": "SAP match", "DATA": "Invoice data",
}


def issue(code: str, severity: str, category: str, message: str, field: str = "",
          invoice_value="", sap_value="", variance: float | None = None, **extra) -> dict:
    d = {"code": code, "severity": severity, "category": category, "field": field,
         "message": message, "invoice_value": "" if invoice_value is None else str(invoice_value),
         "sap_value": "" if sap_value is None else str(sap_value), "variance": variance}
    d.update(extra)
    return d


def hsn_agree(a: str, b: str) -> bool:
    """Complete codes must be identical. A partial prefix (7228 vs 72284000) is NOT proof that the full HSN is right
    (approved rule) - it is reported as a mismatch for a person to judge."""
    a, b = norm_hsn(a), norm_hsn(b)
    return bool(a) and a == b


def check_hsn(h: dict, lines: list[dict]) -> list[dict]:
    """Every invoice line's HSN is compared with the HSN of the PO item that line was matched to in SQL
    (`sap_item_hsn`). Codes that cannot be tied to one item (header HSN of an invoice without line HSN, lines
    not found on the goods receipt) are compared with all HSN codes of the GRN's PO items."""
    out: list[dict] = []
    head = norm_hsn(h.get("hsn_sac"))
    pooled: set[str] = set()
    per_line: list[tuple[int, dict, str, list[str]]] = []
    for idx, l in enumerate(lines):
        code = norm_hsn(l.get("hsn_sac"))
        item_sap = [x.strip() for x in (l.get("sap_item_hsn") or "").split(",") if x.strip()]
        if code and item_sap:
            per_line.append((idx, l, code, item_sap))
        elif code:
            pooled.add(code)
    if head and not any(norm_hsn(l.get("hsn_sac")) for l in lines):
        pooled.add(head)
    inv_all = pooled | {c for _, _, c, _ in per_line}
    sap = [x.strip() for x in (h.get("sap_hsn") or "").split(",") if x.strip()]
    h["hsn_match"] = None
    if not inv_all:
        out.append(issue("HSN_MISSING_INVOICE", RECON, "HSN",
                         "HSN/SAC is not printed on the invoice (it is never taken from SAP)",
                         "hsn_sac", "", ", ".join(sap)))
        return out
    if not h.get("sap_checked") or not h.get("po_in_sap"):
        return out                                           # nothing to compare with yet
    if not sap:
        h["hsn_match"] = False
        out.append(issue("HSN_MISSING_SAP", RECON, "HSN",
                         "HSN/SAC is not maintained for this PO in SAP (EKPO NCM column is empty)",
                         "hsn_sac", ", ".join(sorted(inv_all)), ""))
        return out
    ok = True
    for idx, l, code, item_sap in per_line:                  # line <-> its own PO item
        if not any(hsn_agree(code, s) for s in item_sap):
            ok = False
            name = (l.get("item") or "")[:35]
            out.append(issue("HSN_MISMATCH", RECON, "HSN",
                             f"Line '{name}': HSN {code} on invoice does not match SAP HSN {', '.join(item_sap)} "
                             f"of its PO item", "hsn_sac", code, ", ".join(item_sap), line_index=idx))
    bad = sorted(x for x in pooled if not any(hsn_agree(x, s) for s in sap))
    if bad:
        ok = False
        out.append(issue("HSN_MISMATCH", RECON, "HSN",
                         f"HSN {', '.join(bad)} on invoice does not match SAP HSN {', '.join(sap)}",
                         "hsn_sac", ", ".join(bad), ", ".join(sap)))
    h["hsn_match"] = ok
    return out


def validate(h: dict, lines: list[dict]) -> dict:
    """Fills h['queue'], h['status'], h['issues'], h['validation_status'], h['validation_errors'],
    h['variance_amount']. Returns h."""
    cfg = get_settings()
    iss: list[dict] = []
    sap_on = bool(h.get("sap_checked"))

    # ---------------------------------------------------------------- mandatory data -> BLOCKED
    def need(key: str, label: str, code: str):
        if not h.get(key):
            iss.append(issue(code, BLOCK, "MISSING", f"{label} is missing", key))

    need("invoice_number", "Invoice number", "MISSING_INVOICE_NUMBER")
    need("invoice_date", "Invoice date", "MISSING_INVOICE_DATE")
    need("vendor", "Vendor name", "MISSING_VENDOR")
    need("gstin", "Vendor GSTIN", "MISSING_GSTIN")

    # ---- Service PO block (81/82/83): these invoices must NOT be extracted or posted ----
    _po = h.get("po_number", "")
    if is_service_po(_po):
        iss.append(issue("SERVICE_PO_NOT_ALLOWED", BLOCK, "MISSING",
                         f"PO {_po} is a service PO (prefix {_po[:2]}) — only material POs (51/61) "
                         f"can be extracted and posted through ClearMatch. "
                         f"Service invoices (81/82/83) must be processed manually.",
                         "po_number", _po))
    elif not is_valid_po(_po):
        iss.append(issue("MISSING_PO", BLOCK, "MISSING",
                         "PO number is missing" if not _po
                         else f"PO '{_po}' is not a valid 10-digit number", "po_number", _po))
    if not h.get("grn_number"):
        iss.append(issue("MISSING_GRN", BLOCK, "MISSING", "GRN number is missing", "grn_number"))
    elif not grn_is_valid(h["grn_number"]):
        iss.append(issue("INVALID_GRN", BLOCK, "MISSING",
                         f"GRN '{h['grn_number']}' is not a valid 10-digit number starting with 50",
                         "grn_number", h["grn_number"]))
    unread = set(h.get("unread") or [])
    if "subtotal" in unread or h.get("subtotal", 0) <= 0:
        iss.append(issue("MISSING_TAXABLE_VALUE", BLOCK, "MISSING",
                         "Taxable value could not be read" if "subtotal" in unread else "Taxable value is zero",
                         "subtotal"))
    if "total" in unread or h.get("total", 0) <= 0:
        iss.append(issue("MISSING_TOTAL", BLOCK, "MISSING",
                         "Invoice total could not be read" if "total" in unread else "Invoice total is zero", "total"))
    if "total_tax" in unread:
        iss.append(issue("MISSING_TAX", BLOCK, "MISSING", "No tax amount (CGST / SGST / IGST) could be read",
                         "total_tax"))
    for fld, why in (h.get("parse_errors") or {}).items():
        iss.append(issue("VALUE_NOT_PARSED", RECON, "DATA", f"{fld}: value printed on the invoice was not understood "
                         f"({why}) - treated as unread, not as zero", fld.split(".")[-1]))
    if not h.get("gst_tax_code"):
        iss.append(issue("MISSING_GST_TAX_CODE", BLOCK, "MISSING",
                         "GST tax code could not be determined from the invoice GST %", "gst_tax_code"))
    # plant code comes from SQL (GRN / PO plant) - not demanded from the invoice and not part of the % rule
    # MIRO document type (Details tab) is the document type of that plant - a person chooses when it is not unique
    if sap_on and h.get("plant_code") and not h.get("doc_type"):
        opts = h.get("doc_type_options") or []
        if opts:
            iss.append(issue("DOC_TYPE_CHOOSE", RECON, "DATA", f"Plant {h['plant_code']} has several document types "
                             f"({', '.join(o['doc_type'] + ' ' + (o['description'] or '') for o in opts)}) - choose one",
                             "doc_type", "", ", ".join(o["doc_type"] for o in opts)))
        else:
            iss.append(issue("NO_DOC_TYPE", RECON, "DATA", f"No MIRO document type for plant {h['plant_code']} in the "
                             f"master data - add it under Document types", "doc_type"))

    # ---------------------------------------------------------------- SAP availability
    if not sap_on:
        iss.append(issue("SAP_NOT_CHECKED", RECON, "SAP",
                         "SAP could not be reached - the invoice has not been cross-checked yet"))
    else:
        if h.get("po_number") and is_valid_po(h["po_number"]) and not h.get("po_in_sap"):
            iss.append(issue("PO_NOT_IN_SAP", RECON, "MISSING",
                             f"PO {h['po_number']} not found in SAP (EKKO)", "po_number", h["po_number"]))
        if h.get("grn_number") and not h.get("grn_in_sap"):
            iss.append(issue("GRN_NOT_IN_SAP", RECON, "MISSING",
                             f"GRN {h['grn_number']} not found in SAP (MSEG) by stamp, invoice no, PO or lines",
                             "grn_number", h["grn_number"]))
    if h.get("multi_po_flag"):
        iss.append(issue("MULTI_PO", INFO, "SAP", h.get("red_flag_reason") or "Invoice linked to several POs",
                         "po_number", h.get("po_list", "")))

    # ---------------------------------------------------------------- PO / GRN confidence flags
    # If PO or GRN was extracted by vision (not confirmed from SAP) and confidence < 70, warn
    # This tells the reconciler to manually verify even if the value passed format checks
    fs = h.get("field_sources") or {}
    _po_src = (fs.get("po_number") or "").upper()
    _grn_src = (fs.get("grn_number") or "").upper()
    _conf = h.get("confidence") or 100

    if _po and is_valid_po(_po) and _po_src == "VISION" and _conf < 70 and not sap_on:
        iss.append(issue("PO_LOW_CONFIDENCE", RECON, "MISSING",
                         f"PO {_po} was read by AI (confidence {int(_conf)}%) but SAP has not been checked — "
                         f"please verify this PO number before posting",
                         "po_number", _po))
    if h.get("grn_number") and grn_is_valid(h["grn_number"]) and _grn_src == "VISION" and _conf < 70 and not sap_on:
        iss.append(issue("GRN_LOW_CONFIDENCE", RECON, "MISSING",
                         f"GRN {h['grn_number']} was read by AI (confidence {int(_conf)}%) but SAP has not been checked — "
                         f"please verify this GRN number before posting",
                         "grn_number", h["grn_number"]))

    # ---------------------------------------------------------------- every page processed?
    pi = h.get("page_info") or {}
    if pi:
        if pi.get("pages_failed"):
            iss.append(issue("PAGE_NOT_PROCESSED", RECON, "DATA",
                             f"Page(s) {', '.join(map(str, pi['pages_failed']))} of {pi.get('pages_total')} could not "
                             f"be read by the model - the invoice is incomplete", "pages",
                             ", ".join(map(str, pi["pages_failed"]))))
        if pi.get("pages_skipped"):
            iss.append(issue("PAGE_NOT_PROCESSED", RECON, "DATA",
                             f"{pi['pages_skipped']} page(s) beyond the page limit were not sent to the model",
                             "pages", str(pi["pages_skipped"])))
        if pi.get("illegible_pages"):
            iss.append(issue("PAGE_ILLEGIBLE", RECON, "DATA",
                             f"Page(s) {', '.join(map(str, pi['illegible_pages']))} reported as hard to read",
                             "pages", ", ".join(map(str, pi["illegible_pages"]))))
        for c in pi.get("conflicts") or []:
            iss.append(issue("PAGE_VALUE_CONFLICT", RECON, "DATA",
                             f"{c['field']}: '{c['first']}' and '{c['later']}' were read on different pages "
                             f"({c['pages']})", c["field"], c["first"], c["later"]))
    for a_, b_ in h.get("possible_duplicate_lines") or []:
        iss.append(issue("LINE_POSSIBLE_DUPLICATE", RECON, "DATA",
                         f"Lines {a_} and {b_} are identical (description, quantity, amount) - both kept, please "
                         f"confirm the invoice really prints the row twice", "lines", f"{a_}, {b_}"))
    for i_, l_ in enumerate(lines, 1):
        if l_.get("unread"):
            iss.append(issue("LINE_VALUE_UNREAD", RECON, "DATA",
                             f"Line {i_}: {', '.join(l_['unread'])} could not be read", "lines",
                             ", ".join(l_["unread"]), line_index=i_ - 1))

    # ---------------------------------------------------------------- vendor / currency vs the PO header (EKKO)
    if sap_on and h.get("po_in_sap"):
        inv_cur, sap_cur = (h.get("currency") or "").strip().upper(), (h.get("sap_currency") or "").strip().upper()
        if inv_cur and sap_cur and inv_cur != sap_cur:
            iss.append(issue("CURRENCY_MISMATCH", RECON, "SAP", f"Invoice currency {inv_cur} vs PO currency {sap_cur} "
                             f"(EKKO.WAERS)", "currency", inv_cur, sap_cur))
        inv_v, sap_v = (h.get("vendor_code") or "").strip().lstrip("0"), (h.get("sap_vendor_code") or "").strip().lstrip("0")
        if inv_v and sap_v and inv_v != sap_v:
            iss.append(issue("VENDOR_MISMATCH", RECON, "SAP", f"Vendor code {inv_v} on the invoice vs PO vendor {sap_v} "
                             f"(EKKO.LIFNR)", "vendor_code", inv_v, sap_v))

    # ---------------------------------------------------------------- values vs SAP -> RECONCILE
    for m in h.get("sap_mismatches", []):
        iss.append(issue(m.get("code", "FIELD_MISMATCH"), RECON, "SAP", m["message"], m.get("field", ""),
                         m.get("invoice_value", ""), m.get("sap_value", "")))

    variance_total = 0.0
    for m in h.get("line_mismatches", []):
        cat = "QUANTITY" if m["code"] in ("QTY_MISMATCH", "LINE_NOT_IN_GR") else "PRICE"
        iss.append(issue(m["code"], RECON, cat, m["message"], "lines", m.get("invoice_value", ""),
                         m.get("sap_value", ""), m.get("variance"), line_index=m.get("line_index")))
        variance_total += abs(to_num(m.get("variance")))

    sub, tax, total = h.get("subtotal", 0.0), h.get("total_tax", 0.0), h.get("total", 0.0)
    grn_amt = h.get("grn_amount")
    if grn_amt and sub and abs(grn_amt - sub) > max(cfg.round_tolerance, sub * cfg.amount_tolerance):
        iss.append(issue("GRN_VALUE_MISMATCH", RECON, "PRICE",
                         f"Invoice taxable value {sub:,.2f} vs SAP goods-receipt value {grn_amt:,.2f}",
                         "subtotal", f"{sub:,.2f}", f"{grn_amt:,.2f}", round(sub - grn_amt, 2)))
        if not h.get("line_mismatches"):
            variance_total = abs(sub - grn_amt)
    if h.get("tax_code_match") is False:
        iss.append(issue("TAX_CODE_MISMATCH", RECON, "TAX",
                         f"Invoice GST {h.get('gst_percent')}% maps to tax code {h['gst_tax_code']} but "
                         f"SAP has {h['sap_tax_code']}", "gst_tax_code", h["gst_tax_code"], h["sap_tax_code"]))

    iss += check_hsn(h, lines)

    # ---------------------------------------------------------------- arithmetic on the invoice
    c, s, g = h.get("cgst", 0.0), h.get("sgst", 0.0), h.get("igst", 0.0)
    rt = cfg.round_tolerance
    if not tax and (c + s + g) > 0:                 # NEW: the model no longer returns total_tax - derive it from the 3 taxes
        tax = h["total_tax"] = round(c + s + g, 2)
    ro, oc = to_num(h.get("round_off")), to_num(h.get("other_charges"))      # NEW: printed round-off / extra charges
    arith_ok = not ({"subtotal", "total", "total_tax"} & unread)      # never do arithmetic with an unread value
    if (c + s + g) > 0 and abs((c + s + g) - tax) > rt:
        iss.append(issue("TAX_SPLIT_MISMATCH", RECON, "DATA",
                         f"CGST+SGST+IGST {round(c + s + g, 2)} differs from total tax {tax}", "total_tax"))
    if arith_ok and sub > 0 and total > 0 and abs((sub + tax + ro + oc) - total) > rt:       # round-off and charges included
        extra_txt = (f" + round-off {ro}" if ro else "") + (f" + other charges {oc}" if oc else "")
        iss.append(issue("TOTAL_MISMATCH", RECON, "DATA",
                         f"Taxable {sub} + tax {tax}{extra_txt} differs from invoice total {total}", "total"))
    if c > 0 and abs(c - s) > 0.5:
        iss.append(issue("CGST_SGST_DIFFER", RECON, "DATA", f"CGST {c} differs from SGST {s}", "cgst"))
    if c > 0 and g > 0:
        iss.append(issue("MIXED_GST", RECON, "DATA", "Both CGST/SGST and IGST charged on one invoice", "igst"))
    if h.get("gst_rate_conflict"):
        iss.append(issue("GST_RATE_PRINTED_MISMATCH", RECON, "TAX", f"GST rate {h['gst_rate_conflict']}", "gst_percent"))
    if h.get("gst_percent") is not None and h["gst_percent"] not in GST_STANDARD_RATES:
        iss.append(issue("NON_STANDARD_GST", RECON, "TAX", f"Non-standard GST rate {h['gst_percent']}%",
                         "gst_percent", h["gst_percent"]))
    if h.get("invoice_date") and not re.fullmatch(r"\d{2}\.\d{2}\.\d{4}", h["invoice_date"]):
        iss.append(issue("DATE_UNPARSED", RECON, "DATA", f"Invoice date '{h['invoice_date']}' not understood",
                         "invoice_date", h["invoice_date"]))
    if h.get("gstin") and not GSTIN_RE.match(h["gstin"]):
        iss.append(issue("GSTIN_FORMAT", RECON, "DATA", f"Vendor GSTIN '{h['gstin']}' looks wrong", "gstin",
                         h["gstin"]))
    # ---- NEW: checks that catch typical misreads of the invoice (all on the invoice's own numbers) ----
    _gst = (h.get("gstin") or "").strip().upper()
    if _gst and GSTIN_RE.match(_gst) and not gstin_ok(_gst):          # textutil.repair_gstin already tried to fix it
        iss.append(issue("GSTIN_CHECKSUM", RECON, "DATA",
                         f"Vendor GSTIN '{_gst}' fails the GST check digit - a character was probably misread",
                         "gstin", _gst))
    _seller_state = _gst[:2]
    if _seller_state.isdigit() and not (c > 0 and g > 0):          # c>0 and g>0 is already MIXED_GST
        if _seller_state == BUYER_STATE_CODE and g > 0:
            iss.append(issue("TAX_TYPE_MISMATCH", RECON, "TAX",
                             f"Seller GSTIN is in the buyer's state ({_seller_state}) so CGST+SGST is expected, "
                             f"but IGST {g:,.2f} was read", "igst", g, ""))
        elif _seller_state != BUYER_STATE_CODE and (c > 0 or s > 0):
            iss.append(issue("TAX_TYPE_MISMATCH", RECON, "TAX",
                             f"Seller GSTIN is in another state ({_seller_state}) so IGST is expected, "
                             f"but CGST {c:,.2f} / SGST {s:,.2f} was read", "cgst", c, ""))
    if g > 0 and sub > 0 and abs(g - sub) <= max(1.0, sub * 0.005):
        iss.append(issue("IGST_EQUALS_SUBTOTAL", RECON, "DATA",
                         "IGST equals the taxable value - the wrong box was probably read", "igst", g, sub))
    if sub > 0 and tax > 0 and not (4 <= tax / sub * 100 <= 29):
        iss.append(issue("TAX_RATIO_OUT_OF_BAND", RECON, "DATA",
                         f"Total tax is {tax / sub * 100:.1f}% of the taxable value (expected about 5-28%) - "
                         f"an amount was probably misread", "total_tax", tax, sub))
    _cand = h.get("grn_candidates") or {}                          # set by the extraction step when both places had a GRN
    _g_top, _g_stamp = _cand.get("grn_top_margin") or "", _cand.get("grn_stamp") or ""
    if _g_top and _g_stamp and _g_top != _g_stamp:
        # category MISSING so an approved amount deviation can never waive it (same as GRN_NOT_IN_SAP)
        iss.append(issue("GRN_CONFLICT", RECON, "MISSING",
                         f"Two different GRNs were read: {_g_top} (top margin) and {_g_stamp} (receiving stamp) - "
                         f"{h.get('grn_number') or _g_top} was used, please confirm",
                         "grn_number", f"{_g_top} / {_g_stamp}"))
    if not lines:
        iss.append(issue("NO_LINES", RECON, "DATA", "No line items could be read from the invoice", "lines"))
    else:
        line_sum = round(sum(l.get("amount", 0) or 0 for l in lines), 2)
        if "subtotal" not in unread and sub > 0 and abs(line_sum - sub) > max(rt, sub * cfg.amount_tolerance):
            iss.append(issue("LINES_TOTAL_MISMATCH", RECON, "DATA",
                             f"Line items add up to {line_sum:,.2f} but taxable value is {sub:,.2f}", "lines"))
        # NEW: each row must satisfy quantity x rate = amount (a misread digit shows up here before SAP is checked)
        _bad = [i + 1 for i, l in enumerate(lines)
                if to_num(l.get("quantity")) and to_num(l.get("rate"))
                and abs(to_num(l["quantity"]) * to_num(l["rate"]) - to_num(l.get("amount")))
                > max(1.0, 0.002 * abs(to_num(l.get("amount"))))]
        if _bad:
            iss.append(issue("LINE_QTY_RATE_MISMATCH", QTY_RATE_SEVERITY, "DATA",
                             f"Quantity x rate does not equal the amount on line(s) {', '.join(map(str, _bad[:8]))}",
                             "lines", ", ".join(map(str, _bad))))
    if h.get("confidence") and h["confidence"] < 60:
        iss.append(issue("LOW_CONFIDENCE", RECON, "DATA", f"Low AI confidence ({h['confidence']}%)"))

    # ---------------------------------------------------------------- an approved deviation waives RECON
    if h.get("approved_variance"):
        for i in iss:
            # Only quantity / value variances against the goods receipt can be accepted by an approver. Missing data,
            # arithmetic, tax, vendor/currency, page and line-reading problems are NEVER waived by one approval.
            if i["severity"] == RECON and i["code"] in WAIVABLE_CODES:
                i["severity"] = WAIVED

    # ---------------------------------------------------------------- how much of the invoice was read?
    # 10 mandatory fields. Everything read but a few gaps -> a person completes it in RECONCILE;
    # too much missing (< min_completeness) -> BLOCKED. "Not in SAP" and multi-PO always stay BLOCKED.
    missing = [i for i in iss if i["severity"] == BLOCK and i["code"] in FIELD_MISSING_CODES]
    gone = {i["field"] for i in missing}
    if not norm_hsn(h.get("hsn_sac")) and not any(norm_hsn(l.get("hsn_sac")) for l in (h.get("lines") or [])):
        gone.add("hsn_sac")                      # HSN not read (its own RECON issue is raised in the HSN check)
    done = max(0, len(MANDATORY_FIELDS) - len(gone))
    h["completeness"] = round(done / len(MANDATORY_FIELDS), 2)
    # a PO that could not be read (and could not be found in SQL from the GRN / invoice no.) no longer blocks by itself:
    # 70 % or more read -> RECONCILE, a person types the PO and pushes it. Only < 70 % read stays BLOCKED.
    if missing and h["completeness"] >= cfg.min_completeness - 1e-9:
        for i in missing:
            i["severity"] = RECON
            i["message"] += f" ({int(h['completeness'] * 100)}% of the invoice was read - please complete it)"

    blocked = any(i["severity"] == BLOCK for i in iss)
    recon = any(i["severity"] == RECON for i in iss)
    queue = QUEUE_BLOCKED if blocked else (QUEUE_RECONCILE if recon else QUEUE_MATCHED)
    status = STATUS_MATCHED if queue == QUEUE_MATCHED else STATUS_REVIEW

    h["issues"] = iss
    h["queue"], h["status"], h["validation_status"] = queue, status, status
    h["variance_amount"] = round(variance_total, 2) if variance_total else 0.0
    h["validation_errors"] = {                                # legacy shape (Excel export, older tools)
        "status": status,
        "red_flag": [i["message"] for i in iss if i["code"] == "MULTI_PO"],       # information only
        "missing": [i["message"] for i in iss if i["severity"] == BLOCK and i["code"] != "MULTI_PO"],
        "mismatch": [i["message"] for i in iss if i["severity"] == RECON and i.get("category") != "DATA"],
        "doubt": [i["message"] for i in iss if i["severity"] == RECON and i.get("category") == "DATA"],
    }
    return h


def to_num(v) -> float:
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def exception_type(issues: list[dict]) -> str:
    """Single label for the Error-flow list: the most serious open issue decides.
    Uses .get() for 'category' to safely handle legacy issue dicts that may be missing the key."""
    open_ = [i for i in issues if i.get("severity") in (BLOCK, RECON)]
    if not open_:
        return ""
    if any(i.get("severity") == BLOCK for i in open_):
        return "Blocked"
    if any(i.get("category") == "MISSING" for i in open_):
        return "Data missing"
    for cat, label in (("QUANTITY", "Quantity mismatch"), ("PRICE", "Price variance"),
                       ("TAX", "Tax / HSN"), ("HSN", "Tax / HSN")):
        if any(i.get("category") == cat for i in open_):
            return label
    return "Other mismatch"
