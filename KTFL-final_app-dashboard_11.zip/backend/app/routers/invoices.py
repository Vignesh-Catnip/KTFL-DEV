from __future__ import annotations

from datetime import datetime, timezone
import mimetypes
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from fastapi.responses import FileResponse
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import AuditLog, Invoice, InvoiceLine, QUEUES, User
from ..schemas import InvoiceEdit, ResolveIn  # LineEdit kept in schemas for future typed use
from ..security import current_user, require
from ..config import get_settings
from ..services import doctype, pdfio, robot
from ..services.sap import get_sap, sap_enrich
from ..services.compare import build_compare
from ..services.persist import audit, find_duplicate, header_from_invoice
from ..services.pipeline import recheck_invoice
from ..services.textutil import is_service_po
from .common import apply_effective, invoice_row, iso

router = APIRouter(prefix="/api/invoices", tags=["invoices"])

# edit field -> (Invoice column, header key)
_EDIT_COL = {"total_tax": "tax"}


def _get(db: Session, invoice_id: int) -> Invoice:
    inv = db.get(Invoice, invoice_id)
    if inv is None:
        raise HTTPException(404, "Invoice not found")
    return inv


@router.get("")
def list_invoices(queue: str | None = None, q: str | None = None, plant: str | None = None,
                  miro: str | None = None, page: int = Query(1, ge=1), size: int = Query(50, ge=1, le=200),
                  db: Session = Depends(get_db), _: User = Depends(current_user)):
    stmt = select(Invoice)
    if queue:
        if queue.upper() not in QUEUES:
            raise HTTPException(422, "queue must be MATCHED, RECONCILE or BLOCKED")
        stmt = stmt.where(Invoice.queue == queue.upper())
    if plant:
        stmt = stmt.where(Invoice.plant_code == plant)
    if miro:
        stmt = stmt.where(Invoice.miro_status.is_(None) if miro == "NONE" else Invoice.miro_status == miro)
    if q:
        like = f"%{q.strip()}%"
        stmt = stmt.where(or_(Invoice.invoice_number.ilike(like), Invoice.vendor.ilike(like),
                              Invoice.po_number.ilike(like), Invoice.grn_number.ilike(like)))
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.scalars(stmt.order_by(Invoice.id.desc()).offset((page - 1) * size).limit(size)).all()
    items = [invoice_row(i) for i in rows]
    apply_effective(db, list(rows), items)
    return {"total": total, "page": page, "size": size, "items": items}


@router.get("/{invoice_id}")
def detail(invoice_id: int, db: Session = Depends(get_db), _: User = Depends(current_user)):
    inv = _get(db, invoice_id)
    row = invoice_row(inv)
    row.update({
        "gstin": inv.gstin, "currency": inv.currency, "cgst": inv.cgst, "sgst": inv.sgst, "igst": inv.igst,
        "tax": inv.tax, "po_date": inv.po_date, "grn_date": inv.grn_date, "grn_amount": inv.grn_amount,
        "sap_tax_code": inv.sap_tax_code, "hsn_match": inv.hsn_match, "sap_checked": inv.sap_checked,
        "grn_in_sap": inv.grn_in_sap, "po_list": inv.po_list, "red_flag_reason": inv.red_flag_reason,
        "issues": inv.issues or [], "field_sources": inv.field_sources or {},
        "page_count": inv.page_count, "resolution_note": inv.resolution_note, "resolved_by": inv.resolved_by,
        "resolved_at": iso(inv.resolved_at), "confidence": inv.confidence,
        "handwritten_references": inv.handwritten_references, "company_code": inv.company_code,
        "miro_selected_rows": inv.miro_selected_rows,
        "doc_type_options": doctype.options_for(db, inv.plant_code, get_settings().sap_client or None),
        "compare": build_compare(inv),
        "history": [{"action": a.action, "actor": a.actor, "at": iso(a.created_at), "detail": a.detail}
                    for a in db.scalars(select(AuditLog).where(AuditLog.invoice_id == inv.id)
                                        .order_by(AuditLog.id.desc()).limit(50))],
    })
    apply_effective(db, [inv], [row])
    return row


@router.patch("/{invoice_id}")
def edit(invoice_id: int, body: dict, db: Session = Depends(get_db),
         user: User = Depends(require("approver"))):
    inv = _get(db, invoice_id)
    if inv.miro_status in ("POSTED", "PARKED"):
        raise HTTPException(409, f"Invoice already {inv.miro_status} in SAP - it cannot be edited")

    # Separate line edits (key = "line_NNN") from header edits
    line_changes: dict[int, dict] = {}
    header_raw: dict = {}
    for k, v in body.items():
        if k.startswith("line_"):
            try:
                lid = int(k[5:])
                if isinstance(v, dict):
                    line_changes[lid] = v
            except ValueError:
                pass
        else:
            header_raw[k] = v

    # Apply line edits
    line_before: dict = {}
    for lid, vals in line_changes.items():
        line = db.get(InvoiceLine, lid)
        if line is None or line.invoice_id != inv.id:
            raise HTTPException(404, f"Line {lid} not found on this invoice")
        line_before[lid] = {"item": line.item, "quantity": line.quantity, "amount": line.amount, "hsn_sac": line.hsn_sac}
        if "item" in vals:
            line.item = str(vals["item"]).strip()[:255]
        if "quantity" in vals:
            try:
                line.quantity = float(str(vals["quantity"]).replace(",", ""))
            except ValueError:
                pass
        if "amount" in vals:
            try:
                line.amount = float(str(vals["amount"]).replace(",", ""))
            except ValueError:
                pass
        if "hsn_sac" in vals:
            line.hsn_sac = str(vals["hsn_sac"]).strip()[:50] or None
        if "rate" in vals:
            try:
                line.rate = float(str(vals["rate"]).replace(",", ""))
            except ValueError:
                pass

    # Apply header edits via schema validation
    changes: dict = {}
    before: dict = {}
    if header_raw:
        parsed = InvoiceEdit.model_validate(header_raw)
        changes = parsed.model_dump(exclude_unset=True)
        for k, v in changes.items():
            col = _EDIT_COL.get(k, k)
            before[k] = getattr(inv, col)
            if isinstance(v, str):
                v = v.strip()
            setattr(inv, col, v)
            if k == "doc_type":
                inv.doc_type = (v or "").upper() or None

    if not changes and not line_changes:
        raise HTTPException(422, "Nothing to change")

    if changes and find_duplicate(db, header_from_invoice(inv)[0] | {"invoice_number": inv.invoice_number,
                                                          "po_number": inv.po_number}, exclude_id=inv.id):
        db.rollback()
        raise HTTPException(409, "Another invoice with the same invoice number and PO already exists")

    recheck_invoice(db, inv, actor=user.username, manual_fields=set(changes), action="EDITED")
    if line_before:
        audit(db, "LINES_EDITED", inv.id, {"before": line_before, "lines": {str(k): v for k, v in line_changes.items()}}, user.username)
    if changes:
        audit(db, "FIELDS_EDITED", inv.id, {"before": before, "after": changes}, user.username)
    return {"queue": inv.queue, "status": inv.status}


@router.post("/{invoice_id}/recheck")
def recheck(invoice_id: int, db: Session = Depends(get_db), user: User = Depends(require("approver"))):
    inv = _get(db, invoice_id)
    recheck_invoice(db, inv, actor=user.username)
    return {"queue": inv.queue, "status": inv.status}


@router.post("/{invoice_id}/resolve")
def resolve(invoice_id: int, body: ResolveIn, db: Session = Depends(get_db),
            user: User = Depends(require("approver"))):
    inv = _get(db, invoice_id)
    if inv.queue == "BLOCKED":
        raise HTTPException(409, "A blocked invoice has missing data - correct the data first")
    inv.resolution, inv.resolution_note = body.resolution, body.note
    inv.resolved_by, inv.resolved_at = user.username, datetime.now(timezone.utc)
    inv.approved_variance = body.approve_variance
    recheck_invoice(db, inv, actor=user.username, action="RESOLVED")
    audit(db, "RESOLUTION_SAVED", inv.id, {"resolution": body.resolution, "note": body.note,
                                           "approve_variance": body.approve_variance}, user.username)
    return {"queue": inv.queue, "status": inv.status}


@router.post("/{invoice_id}/push")
def push(invoice_id: int, db: Session = Depends(get_db), user: User = Depends(require("approver"))):
    """Hand the invoice to the MIRO robot (it picks status=MATCHED rows that have no miro_status)."""
    inv = _get(db, invoice_id)
    if inv.queue != "MATCHED" or inv.status != "MATCHED":
        raise HTTPException(409, "Only a fully matched invoice can be pushed to SAP MIRO")
    # Block service POs (81/82/83) from SAP posting — must be processed manually
    if is_service_po(inv.po_number or ""):
        raise HTTPException(409,
            f"Service PO {inv.po_number} (prefix {(inv.po_number or '')[:2]}) cannot be posted through ClearMatch. "
            f"Only material invoices with PO starting 51 or 61 are allowed. Process this invoice manually in SAP.")
    if inv.miro_status in ("POSTED", "PARKED"):
        raise HTTPException(409, f"Invoice is already {inv.miro_status} in SAP — duplicate posting prevented. "
                               f"SAP Journal Entry: {inv.miro_doc_number or 'see SAP logs'}")
    if inv.miro_status in ("IN_PROGRESS", "UNKNOWN"):
        raise HTTPException(409, f"Invoice is already {inv.miro_status} in SAP")
    from ..database import dedupe_protection_ok
    safe, why_not = dedupe_protection_ok()
    if not safe:
        raise HTTPException(409, f"Posting is disabled: {why_not}")
    inv.miro_status, inv.miro_message = None, None
    inv.pushed_by, inv.pushed_at = user.username, datetime.now(timezone.utc)
    audit(db, "PUSHED_TO_MIRO", inv.id, {}, user.username)
    r = robot.trigger(user.username, "MANUAL")
    if r["started"]:
        msg = f"Robot started (run {r['run_id']}) - watch progress under Auto Flow SAP Logs"
    elif r["queued"]:
        msg = "Robot is busy with another invoice - this one follows right after"
    else:
        msg = f"Invoice is queued for the robot. Robot not started: {r['reason']}"
    return {"ok": True, "message": msg, "robot": r}


@router.post("/{invoice_id}/sap-lookup")
def sap_lookup(invoice_id: int, body: dict, db: Session = Depends(get_db),
               user: User = Depends(require("approver"))):
    """Re-query SAP for a manually entered PO or GRN and return matched_details.

    Body: {"po_number": "...", "grn_number": "..."}  (at least one required)
    Returns the SAP data found (po_date, grn_date, grn_amount, vendor_code, plant_code,
    sap_tax_code, company_code, po_in_sap, grn_in_sap) plus any notes.
    Only EKKO, EKPO, MSEG tables are used (security constraint).
    """
    inv = _get(db, invoice_id)
    gw = get_sap()
    if gw is None:
        raise HTTPException(503, "SAP is not connected - cannot look up data")

    # Build a lightweight header dict for sap_enrich
    h, lines = header_from_invoice(inv)
    # Override with user-supplied values
    if "po_number" in body and body["po_number"]:
        h["po_number"] = str(body["po_number"]).strip()
    if "grn_number" in body and body["grn_number"]:
        h["grn_number"] = str(body["grn_number"]).strip()

    if not h.get("po_number") and not h.get("grn_number"):
        raise HTTPException(422, "Provide at least one of po_number or grn_number")

    # Run SAP enrichment — allow_grn_switch=False since the user typed the GRN explicitly
    notes = sap_enrich(gw, h, lines, allow_grn_switch=not bool(body.get("grn_number")))

    # Return useful matched_details fields
    result = {
        "po_in_sap": h.get("po_in_sap", False),
        "grn_in_sap": h.get("grn_in_sap", False),
        "grn_number": h.get("grn_number", ""),
        "po_number": h.get("po_number", ""),
        "po_date": h.get("po_date", ""),
        "grn_date": h.get("grn_date", ""),
        "grn_amount": h.get("grn_amount"),
        "vendor_code": h.get("vendor_code", ""),
        "sap_vendor_code": h.get("sap_vendor_code", ""),
        "plant_code": h.get("plant_code", ""),
        "sap_tax_code": h.get("sap_tax_code", ""),
        "company_code": h.get("company_code", ""),
        "po_list": h.get("po_list", ""),
        "sap_hsn": h.get("sap_hsn", ""),
        "notes": notes,
        "field_sources": h.get("field_sources", {}),
    }
    audit(db, "SAP_MANUAL_LOOKUP", inv.id,
          {"po": body.get("po_number"), "grn": body.get("grn_number"), "found": result["po_in_sap"] or result["grn_in_sap"]},
          user.username)
    return result


@router.get("/{invoice_id}/page/{page}.png")
def page_image(invoice_id: int, page: int, zoom: float = 1.6, db: Session = Depends(get_db),
               _: User = Depends(current_user)):
    inv = _get(db, invoice_id)
    path = pdfio.locate_pdf(inv.filename, inv.source_path)
    if path is None:
        raise HTTPException(404, "Original PDF not found on the server")
    if page < 1 or page > pdfio.page_count(path):
        raise HTTPException(404, "No such page")
    return Response(pdfio.render_page_png(path, page, min(max(zoom, 0.5), 3.0)), media_type="image/png",
                    headers={"Cache-Control": "private, max-age=3600"})


@router.get("/{invoice_id}/file")
def original(invoice_id: int, db: Session = Depends(get_db), _: User = Depends(current_user)):
    inv = _get(db, invoice_id)
    path = pdfio.locate_pdf(inv.filename, inv.source_path)
    if path is None:
        raise HTTPException(404, "Original PDF not found on the server")
    return FileResponse(Path(path), media_type=mimetypes.guess_type(str(path))[0] or "application/pdf", filename=inv.filename)
